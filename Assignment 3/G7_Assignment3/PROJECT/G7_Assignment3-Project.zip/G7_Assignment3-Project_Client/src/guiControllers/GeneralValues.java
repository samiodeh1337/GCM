package guiControllers;

/**
 * The Class GeneralValues.
 */
public class GeneralValues {
	
	/** The country. selected country on each scene*/
	public static entities.Country COUNTRY;
	
	/** The city. selected city on each scene*/
	public static entities.City CITY;
	
	/** The Found department manager. */
	public static boolean Found_Department_manager = false; 

}
