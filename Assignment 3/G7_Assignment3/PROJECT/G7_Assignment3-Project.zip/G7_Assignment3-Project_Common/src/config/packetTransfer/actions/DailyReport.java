/*
* this class defines the actions and the name of DailyReport window
 */
package config.packetTransfer.actions;

// TODO: Auto-generated Javadoc
/**
 * The Class DailyReport.
 * Static class
 * Consists of variable's for packet.
 */
public final class DailyReport {

	/** The Constant WINDOW_ECITCITY. */
	public static final String WINDOW = "REPORT";
	
	/* ======================== GET ============================= */
	/** The Constant SUB_ACTION_GET_REPORTS. */
	public static final String SUB_ACTION_GET_REPORTS = "GET_REPORTS";
	
	/* ======================== ADD ============================= */
	
	/* ======================== UPDATE ============================= */

	/* ======================== DELETE ============================= */
	
	/**
	 * Override public contractor to make it static.
	 */
	private DailyReport() { super(); }
}
