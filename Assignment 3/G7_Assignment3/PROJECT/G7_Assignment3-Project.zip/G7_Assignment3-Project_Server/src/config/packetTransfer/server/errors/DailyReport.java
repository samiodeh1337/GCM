/*
 * this class defines errors for DailyReport actions
 */
package config.packetTransfer.server.errors;

// TODO: Auto-generated Javadoc
/**
 * The Class DailyReport.
 * Static class
 * Consists of variable's for packet.
 */
public final class DailyReport {

	/* ======================== GET ============================= */
	/** The Constant SUB_ACTION_ERROR_GET_REPORTS. */
	public static final String SUB_ACTION_ERROR_GET_REPORTS = "failed to get reports";
	
	/* ======================== ADD ============================= */
	
	/* ======================== UPDATE ============================= */

	/* ======================== DELETE ============================= */
	/**
	 * Override public contractor to make it static.
	 */
	private DailyReport() { super(); }
}
